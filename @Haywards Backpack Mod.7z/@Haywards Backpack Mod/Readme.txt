Installation: 
1. Copy the HaywardGB.bikey file to your servers Key folder.
2. Add '@Haywards Backpack Mod' to your server start line.
3. Start server and you're ready to go. Read on for more details.

Info:
- Developed exclusively for use on Unit487 Dayz Server 
- You are welcome to edit and repack for your own server.
- Backpack slots for all vanilla bags have been doubled. 
- Certain bags have perks: weapon slots, cooking pot slot, cooking tripod etc.
-- Not all bags have perks, and the perks increase or decrease with bag capacity.
- All bags come with full insulation and are waterproof(ish).