name = "CheckPulse"; 									// name 
picture = "CheckPulse/images/logos/modlogohover.edds";		// picture in expanded description
logoSmall = "CheckPulse/images/logos/modlogohover.edds";		// icon next to mod name when description is not expanded
logo = "CheckPulse/images/logos/modlogo.edds";			// logo below game menu
logoOver = "CheckPulse/images/logos/modlogohover.edds";		// on mouse hover over logo
tooltip = "CheckPulse - By Cleetus";						// tool tip on mouse hover
overview = "CheckPulse is a mod that adds the ability to see the player's name as well as checking the name and pulse of bodies on the ground."; 					// overview
action = "https://steamcommunity.com/sharedfiles/filedetails/?id=1713355959";				// link
author = "Cleetus";										// author
version = "2.0";										// version