name = "ZomBerry Admin Tools";
author = "Vaker";
version = "0.6.0";
overview = "Simple and customisable Client/Server admin tools with GUI (SP/MP)"; 	// description
action = "https://steamcommunity.com/sharedfiles/filedetails/?id=1582756848";		// link
tooltip = "ZomBerry Admin Tools";
picture = "set:zomberry_images image:ZBMenuLogo";									// normal
logoSmall = "set:zomberry_images image:ZBMenuLogo";									// small
logo = "set:zomberry_images image:ZBMenuLogo";										// small
logoOver = "set:zomberry_images image:ZBMenuLogoOver";								// over